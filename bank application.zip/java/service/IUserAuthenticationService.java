package service;

import dto.CustomerDetails;

public interface IUserAuthenticationService {
	CustomerDetails registration(CustomerDetails customer);
}
