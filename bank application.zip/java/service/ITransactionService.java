package service;

public interface ITransactionService {

}
