package service;

public class ITransactionServiceImpl implements ITransactionService {

}
