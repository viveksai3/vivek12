package dao;

public interface ITransaction {

}
