package dao;

import dto.CustomerDetails;

public interface IUserAuthentication {

	CustomerDetails registration(CustomerDetails customer);



}
