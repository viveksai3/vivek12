package dao;

public class TransactionImpl implements ITransaction {

}
