package ui;

import java.util.Scanner;

import dao.IUserAuthentication;
import dto.CustomerDetails;
import service.IUserAuthenticationService;
import service.IUserAuthenticationServiceImpl;
public class Main {
	public static void main(String args[])
	{
		IUserAuthenticationServiceImpl userImpl=new IUserAuthenticationServiceImpl();
		//serviceuserIMpl
		IUserAuthenticationService userService=new IUserAuthenticationServiceImpl();
		//customerdetails obj
		CustomerDetails customer=new CustomerDetails();
		Scanner info=new Scanner(System.in);
		System.out.println("enter choice :\n 1)registration\n2)login");
		int ch=info.nextInt();
	
		switch(ch)
		{
		case 1:System.out.println("enter first name");
		customer.setFirstName(info.next());
		System.out.println("enter last name");
		customer.setLastName(info.next());
		System.out.println("enter email id");
		customer.setEmailId(info.next());
		System.out.println("enter password");
		customer.setPassword(info.next());
		System.out.println("enter pan card number");
		customer.setPancardNo(info.next());
		System.out.println("enter aadhar card number");
		String aadhar=info.next();
		if(userImpl.isAadharNo(aadhar))
		{
			customer.setAadharNumber(aadhar);
		}
		else
		{
			System.out.println("invalid aadhar number");
			System.exit(0);
		
		}
		System.out.println("enter address");
		customer.setAddress(info.next());
		System.out.println("enter mobile number");
		String mobile=info.next();
		if(userImpl.isMobileNumber(mobile))
		{
			customer.setMobileNumber(mobile);
		}
		else
		{
			System.out.println("invalid mobile number");
			System.exit(0);;
		}
		customer.setBalance(0);
		//service class...calling registration method
			if(userService.registration(customer)!=null)
			{
				System.out.println("successful");
				System.out.println("press 1 continue");
				
			}
			else
				System.out.println("fail");
			break;
		}
		//case 2:login();
			//break;
		}
	}


