package service;

import dto.CustomerDetails;

public interface IUserAuthenticationService {
	CustomerDetails registration(CustomerDetails customer);

	boolean login(int accNo, String password);
}
