package ui;

import java.util.Scanner;

import dao.IUserAuthentication;
import dto.CustomerDetails;
import dto.Transactions;
import service.ITransactionService;
import service.ITransactionServiceImpl;
import service.IUserAuthenticationService;
import service.IUserAuthenticationServiceImpl;
public class Main {
	static Main main=new Main();
	static Scanner info=new Scanner(System.in);

	IUserAuthenticationServiceImpl userImpl=new IUserAuthenticationServiceImpl();
	 //serviceuserIMpl
	static IUserAuthenticationService userService=new IUserAuthenticationServiceImpl();
	//customerdetails obj
	CustomerDetails customer=new CustomerDetails();
	//transaction service object
	ITransactionService transactionService=new ITransactionServiceImpl();
	//transactions pojo object
	Transactions trans=new Transactions();
	void register()
	{
		System.out.println("enter first name");
		customer.setFirstName(info.next());
		System.out.println("enter last name");
		customer.setLastName(info.next());
		System.out.println("enter email id");
		customer.setEmailId(info.next());
		System.out.println("enter password");
		customer.setPassword(info.next());
		System.out.println("enter pan card number");
		customer.setPancardNo(info.next());
		System.out.println("enter aadhar card number");
		String aadhar=info.next();
		if(userImpl.isAadharNo(aadhar))
		{
			customer.setAadharNumber(aadhar);
		}
		else
		{
			System.out.println("invalid aadhar number");
			System.exit(0);
		
		}
		System.out.println("enter address");
		customer.setAddress(info.next());
		System.out.println("enter mobile number");
		String mobile=info.next();
		if(userImpl.isMobileNumber(mobile))
		{
			customer.setMobileNumber(mobile);
		}
		else
		{
			System.out.println("invalid mobile number");
			System.exit(0);;
		}
		customer.setBalance(0);
		//service class...calling registration method
			System.out.println("your account number is: "+userService.registration(customer).getAccountNumber());
			
				System.out.println("successful!!!.... continuing to login");
				//System.out.println("your account number is:"+accno);
				//calling login after successful registraton
				login();
				
			
			
		
	}
	
	//AFTER SUCCESSFUL REGISTRATION
	void login()
	{
		System.out.println("accout number");
		int accNo=info.nextInt();
		System.out.println("enter password");
		String password=info.next();
		if(userService.login(accNo,password))
		{
			System.out.println("login successul");
			//allowing the transaction menu after success login
			tansactionMenu(accNo);
		}
		else
		{
			System.out.println("login failed");
		}
	}
	//MENU AFTER SUCCESSFUL LOGIN
	void tansactionMenu(int accNo)
	{
		System.out.println("enter choice"+"\n"+"MENU \n1)deposit\n2)withdraw\n3)balanceCheck\n4)transfer");
		int ch=info.nextInt();

		switch(ch)
		{
		case 1: dep(accNo);
		break;
		case 2:withdraw(accNo);
		break;
		case 3:balanceCheck(accNo);
		break;
		case 4:transfer(accNo);
		break;
		}
	}
	//DEPOSIT
	void dep(int accNo)
	{
		System.out.println("enter deposit amount");
		int depAmt=info.nextInt();
		System.out.println("RS:"+depAmt+"deposited into your account");
		System.out.println("updated balance is :"+ transactionService.deposit(depAmt,accNo).getBalance());

	}
	//WITHDRAW
	void withdraw(int accNo)
	{
		System.out.println("enter withdraw amount");
		int withdrawAmt=info.nextInt();
		System.out.println("RS:"+withdrawAmt+"withdrawn from your account");
		System.out.println("updated balance is :"+ transactionService.withdraw(withdrawAmt,accNo).getBalance());

	}
	
	//BALANCE CHECK
	void balanceCheck(int accNo)
	{
		int bal=transactionService.balanceCheck(accNo);
		System.out.println("available balance is:"+bal);
	}
	//TRANSFER
	void transfer(int accNo)
	{
		System.out.println("enter to account number");
		trans.setToAccountNumber(info.nextLong());
		System.out.println("enter amount you want to transfer");
		trans.setAmountTransfer(info.nextLong());
		trans.setFromAccountNumber(accNo);
		//transaction method
		int transid=transactionService.transfer(trans);
		System.out.println("your trasaction id is:"+transid);
		
		
	}
	public static void main(String args[])
	{

		System.out.println("enter choice :\n 1)registration\n2)login");
		int ch=info.nextInt();
	
		switch(ch)
		{
		case 1:main.register();
			
		case 2:main.login();
			
		}
	}
}


