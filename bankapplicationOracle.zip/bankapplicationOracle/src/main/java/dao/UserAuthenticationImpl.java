package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dto.CustomerDetails;
import utility.Database;

public class UserAuthenticationImpl implements IUserAuthentication {
	Database database=new Database();


	public CustomerDetails registration(CustomerDetails customer)  {
		int accno=0;
		try
		{
		String statement="insert into customer_details(first_name,last_name,email_id,password,pancard_number,aadhar_number,address,mobile_number,balance) values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement pst=database.database().prepareStatement(statement);
		pst.setString(1,customer.getFirstName());
		pst.setString(2,customer.getLastName());
		pst.setString(3,customer.getEmailId());
		pst.setString(4,customer.getPassword());
		pst.setString(5,customer.getAadharNumber());
		pst.setString(6,customer.getAddress());
		pst.setString(7, customer.getAddress());
		pst.setString(8,customer.getMobileNumber());
		pst.setLong(9, customer.getBalance());
		pst.executeUpdate();
		
		String statement1="select * from customer_details where aadhar_number=?";
		PreparedStatement pst1=database.database().prepareStatement(statement1);
		pst1.setString(1,customer.getAadharNumber());
		ResultSet re=pst1.executeQuery();
		while(re.next())
		
			customer.setAccountNumber(re.getInt(1));
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return customer;
	}

	public boolean login(int AccountNumber, String password) {
		boolean status=false;
		try
		{
		String statement1="select * from customer_details";
		PreparedStatement pst1=database.database().prepareStatement(statement1);
		ResultSet resultSet=pst1.executeQuery();
		while(resultSet.next())
		{
			//System.out.println(resultSet.getInt(1)+" "+resultSet.getString(5)+AccountNumber+password);
			if(resultSet.getInt(1)==AccountNumber && resultSet.getString(5).contentEquals(password))
			{
				status=true;
				break;
				
			}
			
		}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}

}
