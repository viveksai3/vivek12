package dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import dto.Transactions;
import junit.framework.Assert;

class TransactionImplTest {
	TransactionImpl object=new TransactionImpl();
	Transactions obj1=new Transactions();
	@Test
	void testDeposit() {
		Assert.assertEquals(50,object.deposit(5,1).getBalance());

	}

	@Test
	void testWithdraw() {
		Assert.assertEquals(45,object.withdraw(5,1).getBalance());
	}

	@Test
	void testBalanceCheck() {
		Assert.assertEquals(50,object.balanceCheck(1));
	}

	@Test
	void testTransfer() {
		obj1.setAmountTransfer(5);
		obj1.setFromAccountNumber(1);
		obj1.setToAccountNumber(2);
		object.transfer(obj1);
		Assert.assertEquals(109,object.transfer(obj1));

		
	}

}
