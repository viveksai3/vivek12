package dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import junit.framework.Assert;

class UserAuthenticationImplTest {
	UserAuthenticationImpl object=new UserAuthenticationImpl();

	//@Test
	void testRegistration() {
	}

	@Test
	void testLogin() {
		Assert.assertEquals(true,object.login(1,"fgh"));
	}

}
